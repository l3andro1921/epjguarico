
<?php $__env->startSection('title', 'Noticias'); ?>
<?php $__env->startSection('noticias', 'active'); ?>
<?php $__env->startSection('container-title', 'Noticias'); ?>
<?php $__env->startSection('breadcrumb', ''); ?>

<?php $__env->startSection('buscar'); ?>
    <form class="form-inline ml-3">
        <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="text" name="buscar" placeholder="Buscar Noticia" aria-label="Buscar" required>
            <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">



            <div class="card">
                <div class="card-header border-0">
                    <h3 class="card-title">Noticias Registradas</h3>
                    <div class="card-tools">
                        <a href="#" class="btn btn-tool btn-sm">
                            <i class="fas fa-download"></i>
                        </a>
                        <a href="<?php echo e(route('noticias.create')); ?>" class="btn btn-tool btn-sm">
                            <i class="fas fa-pencil-alt"></i>
                        </a>
                        
                    </div>
                </div>
                <div class="card-body">

                    <div class="row">
                        <table class="table table-hover table-valign-middle table-sm table-bordered table-responsive-sm">
                            <thead class="thead-dark">
                            <tr class="text-center">
                                <th>Titulo</th>
                                <th>Lugar</th>
                                <th>Fecha</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="text-center table-primary text-sm">
                                    <td class="text-left">
                                        <a href="<?php echo e(asset('img/noticias/'.$noticia->imagen)); ?>"
                                           data-rel="lightcase" title="<?php echo e($noticia->titulo); ?>">
                                            <img src="<?php echo e(asset('img/noticias/'.$noticia->imagen)); ?>" alt="<?php echo e($noticia->titulo); ?>" class="img-circle img-size-32 mr-2">
                                        </a>
                                        <?php echo e($noticia->titulo); ?>

                                    </td>
                                    <td class="text-left"><?php echo e(strtolower($noticia->lugar)); ?></td>
                                    <td><?php echo e($carbon->parse($noticia->fecha)->format('d-m-Y')); ?></td>
                                    <td style="width: 10px">
                                        <?php echo Form::open(['route' => ['noticias.destroy', $noticia->id], 'method' => 'DELETE']); ?>

                                        <div class="btn-group">
                                            <a href="<?php echo e(route('noticias.show', $noticia->id)); ?>" class="btn btn-default btn-sm text-info" title="Ver">
                                                <i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('noticias.edit', $noticia->id)); ?>" class="btn btn-default btn-sm text-warning" title="Editar">
                                                <i class="fas fa-pencil-alt"></i></a>
                                            
                                            <button type="submit" onclick="return confirm('Desea Eliminar la Noticia <?php echo e($noticia->titulo); ?>')" class="btn btn-default btn-sm text-danger" title="Eliminar">
                                                <i class="far fa-trash-alt"></i></button>
                                        </div>
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row text-sm justify-content-end">
                        <?php echo $noticias->render(); ?>

                    </div>
                </div>
            </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        jQuery(document).ready(function($) {
            $('a[data-rel^=lightcase]').lightcase();
        });

    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/admin/noticias/index.blade.php ENDPATH**/ ?>