<div class="float-right d-none d-sm-block">
    <b>Version</b> 0.0.1
</div>
<strong>
    Creado por <a href="mailto:leothan522@gmail.com">Leandro Acosta</a>
    Basado en <a href="http://adminlte.io">AdminLTE.io</a>.
</strong>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/main-footer.blade.php ENDPATH**/ ?>