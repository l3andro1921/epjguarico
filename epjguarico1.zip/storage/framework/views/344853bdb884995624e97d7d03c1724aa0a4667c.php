<?php if($actividades): ?>
<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($contador = 0); ?>

    <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($participante->datos_id == $datos->id): ?>
            <?php ($contador = $contador + 1); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(!$contador): ?>
        <?php continue; ?>
    <?php endif; ?>

        <div class="post">
            <div class="user-block">
                <?php if($imagen): ?>
                    <?php ($foto = 'img/users_img/'.$imagen->nombre_imagen); ?>
                <?php else: ?>
                    <?php ($foto = 'img/user.jpg'); ?>
                <?php endif; ?>
                <img class="img-circle img-bordered-sm" src="<?php echo e(asset($foto)); ?>" alt="user image">
                <span class="username">
                                  <a href="#"><?php echo e(ucwords(Auth::user()->name)); ?></a>
                              
                                </span>
                <span class="description"><?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>
            </div>
            <!-- /.user-block -->
            <h3 class="text-primary"><i class="far fa-flag"></i> <?php echo e(strtoupper($actividad->nombre_evento)); ?></h3>
            <p>
                <?php echo e($actividad->descripcion); ?>

            </p>
            <h4><span class="text-sm text-success text-bold">Lugar:</span> <strong class="text-muted"><?php echo e(ucfirst($actividad->lugar_evento)); ?></strong></h4>
            <h6>
                <span class="text-sm text-success text-bold">Fecha Inicio:</span> <strong class="text-muted"><?php echo e($carbon->parse($actividad->fecha_inicio)->format('d-m-Y')); ?></strong>
                <span class="float-right">
                                            <span class="text-sm text-success text-bold">Fecha Final:</span> <strong class="text-muted"><?php echo e($carbon->parse($actividad->fecha_final)->format('d-m-Y')); ?></strong>
                                        </span>
            </h6>
            <br>
            <p class="text-muted">
                <?php if($actividad->id_coordinador == $datos->id): ?>
                    <i class="far fa-fw fa-user"></i> Coordinador<br>
                <?php endif; ?>
                <?php if($actividad->id_administrador == $datos->id): ?>
                    <i class="far fa-fw fa-user"></i> Administrador<br>
                <?php endif; ?>
                <?php if($actividad->id_asesor == $datos->id): ?>
                    <i class="far fa-fw fa-user"></i> Asesor<br>
                <?php endif; ?>

            <?php ($opcion = true); ?>
            <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($participante->status == "Inscrito"): ?>
                    <i class="far fa-fw fa-user"></i> Participante<br>
                <?php endif; ?>
                <?php if($participante->status == "AGENDA" && $participante->datos_id == $datos->id): ?>
                    <?php if($opcion): ?>
                        <?php ($opcion = false); ?>
                        <i class="far fa-fw fa-user"></i> Exponente<br>
                        <?php ($contador = 0); ?>
                        <?php $__currentLoopData = $participante->agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($contador = $contador + 1); ?>
                            &emsp;&emsp;<em>Mensaje <?php echo e($contador); ?>: <span class="text-info"><?php echo e($agenda->mensaje); ?></span></em><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
            <p>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-primary text-sm mr-2"><i class="fas fa-folder"></i> Ver</a>
                
                <span class="float-right">
                                  <a href="#" class="link-black text-sm">
                                    <i class="far fa-comments mr-1"></i> Comments (5)
                                  </a>
                                </span>
            </p>
        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="timeline timeline-inverse">
<div>
    <i class="far fa-clock bg-gray"></i>
</div>
</div>
<?php if($actividades): ?>
<div class="float-right">
    <?php echo e($actividades->render()); ?>

</div>
<?php endif; ?>

<?php /**PATH C:\laragon\www\epjguarico1\resources\views/miembro/home/actividades.blade.php ENDPATH**/ ?>