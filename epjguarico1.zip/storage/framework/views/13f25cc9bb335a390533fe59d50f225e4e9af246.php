<div class="p-3">
    

    <ul class="nav nav-pills flex-column">
        <li class="nav-item">
            <a href="/" class="nav-link" target="_blank">
                 Inicio
            </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="nav-item">
            <span class="text-small text-muted float-right">¿Quienes Somos?</span>
        </li>
        <li class="nav-item active">
            <a href="<?php echo e(route('historia')); ?>" class="nav-link" target="_blank">
                 Nuestra Historia
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('fundador')); ?>" class="nav-link"target="_blank">
                 Nuestro Fundador
            </a>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(route('metas')); ?>" class="nav-link" target="_blank">
                 Metas y Objetivos
               
            </a>
        </li>
        
        <li class="dropdown-divider"></li>
        <li class="nav-item">
            <a href="<?php echo e(route('mieventos.index')); ?>" class="nav-link" target="_blank">
                 Eventos
            </a>
        </li>
        <li class="dropdown-divider"></li>
        <li class="nav-item">
            <a href="<?php echo e(route('galeria')); ?>" class="nav-link" target="_blank">
                 Galeria
            </a>
        </li>
        <li class="dropdown-divider"></li>
    </ul>

</div>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/control-sidebar.blade.php ENDPATH**/ ?>