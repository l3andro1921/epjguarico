
<?php $__env->startSection('title', 'Usuarios'); ?>
<?php $__env->startSection('usuarios', 'active'); ?>
<?php $__env->startSection('container-title', 'Usuarios'); ?>
<?php $__env->startSection('breadcrumb', ''); ?>

<?php $__env->startSection('buscar'); ?>
    <form class="form-inline ml-3">
        <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="text" name="buscar" placeholder="Buscar Usuario" aria-label="Buscar" required>
            <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">



            <div class="card">
                <div class="card-header border-0">
                    <h3 class="card-title">Usuarios Registrados</h3>
                    <div class="card-tools">
                        <a href="#" class="btn btn-tool btn-sm">
                            <i class="fas fa-download"></i>
                        </a>
                        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-tool btn-sm">
                            <i class="fas fa-user-plus"></i>
                        </a>
                        
                    </div>
                </div>
                <div class="card-body">

                    <div class="row">
                    <table class="table table-hover table-valign-middle table-sm table-bordered table-responsive-sm">
                        <thead class="thead-dark">
                        <tr class="text-center">
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Tipo de Usuario</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($usuario->img): ?>
                                <?php ($foto = 'img/users_img/'.$usuario->img); ?>
                            <?php else: ?>
                                <?php ($foto = 'img/user.jpg'); ?>
                            <?php endif; ?>

                        <tr class="text-center table-primary text-sm">
                            <td class="text-left">
                                <a href="<?php echo e(asset($foto)); ?>"
                                   data-rel="lightcase" title="<?php echo e($usuario->name); ?>">
                                    <img src="<?php echo e(asset($foto)); ?>" alt="<?php echo e($usuario->email); ?>" class="img-circle img-size-32 mr-2">
                                </a>
                                <?php echo e($usuario->name); ?>

                            </td>
                            <td class="text-left"><?php echo e(strtolower($usuario->email)); ?></td>
                            <td><?php echo e($usuario->type); ?></td>
                            <td style="width: 10px">
                                <?php echo Form::open(['route' => ['usuarios.destroy', $usuario->id], 'method' => 'DELETE']); ?>

                                <div class="btn-group">
                                    <a href="<?php echo e(route('usuarios.show', $usuario->id)); ?>" class="btn btn-default btn-sm text-info" title="Ver">
                                        <i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>" class="btn btn-default btn-sm text-warning" title="Editar">
                                        <i class="fas fa-pencil-alt"></i></a>
                                    <a href="<?php echo e(route('imagen.usuario', $usuario->id)); ?>" class="btn btn-default btn-sm" title="Cambiar Tipo">
                                        <i class="fas fa-camera"></i></a>
                                    <button type="submit" onclick="return confirm('Desea Eliminar al Usuario <?php echo e($usuario->name); ?>')" class="btn btn-default btn-sm text-danger" title="Eliminar">
                                        <i class="far fa-trash-alt"></i></button>
                                </div>
                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                    <div class="row text-sm justify-content-end">
                        <?php echo $usuarios->render(); ?>

                    </div>
                </div>
            </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        jQuery(document).ready(function($) {
            $('a[data-rel^=lightcase]').lightcase();
        });

    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>