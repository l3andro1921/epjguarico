
<?php $__env->startSection('title', 'Galeria'); ?>
<?php $__env->startSection('galeria', 'active'); ?>
<?php $__env->startSection('container-title', 'Galeria'); ?>
<?php $__env->startSection('breadcrumb', ''); ?>

<?php $__env->startSection('buscar'); ?>
    <form class="form-inline ml-3">
        <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="text" name="buscar" placeholder="Buscar En Galeria" aria-label="Buscar" required>
            <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row d-flex justify-content-center">
        <div class="col-lg-11">

            <div class="card">
               <div class="card-header border-0">
                    <h3 class="card-title">Galeria de Imagenes</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('galeria.carga')); ?>" class="btn btn-primary btn-sm mb-2">Agregar Imagen</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-sm-3">
                            <a href="<?php echo e(Storage::disk('public')->url($gallery->imagen)); ?>" data-toggle="lightbox" data-title="Imagen 1" data-gallery="gallery">
                                <img src="<?php echo e(Storage::disk('public')->url($gallery->imagen)); ?>" class="img-thumbnail mb-2" alt="imagen">
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-center text-danger">No Hay Imagenes Disponibles</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if(count($galleries)): ?>
                <div class="mt-2 mx-auto">
                    <?php echo e($galleries->links()); ?>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make("layouts.admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/admin/galeria/index.blade.php ENDPATH**/ ?>