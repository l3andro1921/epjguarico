<div class="float-right d-none d-sm-block">
    <b>Version</b> 0.0.1
</div>

    Made by <strong><a href="mailto:leothan522@gmail.com">Leandro Acosta</a></strong>
    Based on <strong><a href="http://adminlte.io">AdminLTE.io</a></strong>

<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/guest/main-footer.blade.php ENDPATH**/ ?>