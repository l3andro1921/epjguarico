
<?php $__env->startSection('galeria', 'active'); ?>
<?php $__env->startSection('container-title', 'Carga De Imagen'); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('galeria.home')); ?>">Galeria</a></li>
    <li class="breadcrumb-item active">Cargar Imagen</li>
<?php $__env->stopSection(); ?> 

    <div class="row justify-content-center">
        <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
                <?php echo Form::open(['route' => 'galeria.create','method' => 'POST', 'files' => true, ]); ?>

                <div class="card-body">
                    <div class="form-group">
                        <label>Agregar Imagen a galeria</label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" name="image" class="custom-file-input" id="imgInp" accept="image/png, image/jpeg" required>
                                <label class="custom-file-label" for="exampleInputFile">Seleccionar Imagen</label>
                            </div>
                        </div>
                    </div>

                    <div class="form-group text-center">
                        <img id="blah" src="" class="img-fluid" width="50%" height="50%" />
                    </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer text-right">
                    <input type="hidden" name="id_user" value="#">
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>

                <?php echo Form::close(); ?>

            </div>
            <!-- /.card -->




        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function readImage (input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result); // Renderizamos la imagen
                    $('#blah').attr('class', 'img-thumbnail');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            // Código a ejecutar cuando se detecta un cambio de archivO
            readImage(this);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/admin/galeria/create.blade.php ENDPATH**/ ?>