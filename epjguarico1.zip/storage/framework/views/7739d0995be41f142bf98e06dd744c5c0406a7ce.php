<a href="<?php echo e(route('home')); ?>" class="brand-link">
    <img src="<?php echo e(asset('img/logo_movimiento.jpg')); ?>" alt="Logo" class="brand-image img-circle elevation-3"
         style="opacity: .8">
    <span class="brand-text font-weight-light">EPJ Guárico</span>
</a>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/logo.blade.php ENDPATH**/ ?>