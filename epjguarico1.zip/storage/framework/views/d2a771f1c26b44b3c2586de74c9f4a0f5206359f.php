<div class="sidebar">

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            <li class="nav-item">
                <a href="<?php echo e(route('noticias.index')); ?>" class="nav-link <?php echo $__env->yieldContent('noticias'); ?>">
                    <i class="nav-icon far fa-bookmark"></i>
                    <p>
                        Noticias
                        
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('galeria.home')); ?>" class="nav-link <?php echo $__env->yieldContent('galeria'); ?>">
                   <i class="far fa-dot-circle nav-icon"></i>
                    <p>
                        Galeria
                        
                    </p>
                </a>
            </li>
            <li class="nav-item has-treeview">
                <a href="#" class="nav-link">
                    <i class="nav-icon far fa-calendar-alt"></i>
                    <p>
                        Administrar Eventos
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('eventos.index')); ?>" class="nav-link">
                            <i class="nav-icon far fa-calendar-alt"></i>
                            <p>Eventos</p>
                        </a>
                    </li>
                    
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('configuracion.index')); ?>" class="nav-link <?php echo $__env->yieldContent('configuracion'); ?>">
                            <i class="fas fa-cog nav-icon"></i>
                            <p>Configuración</p>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('usuarios.index')); ?>" class="nav-link <?php echo $__env->yieldContent('usuarios'); ?>">
                    <i class="nav-icon fas fa-users"></i>
                    <p>
                        Usuarios
                        
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('miembros.index')); ?>" class="nav-link <?php echo $__env->yieldContent('miembros'); ?>">
                    <i class="nav-icon fas fa-chart-pie"></i>
                    <p>
                        Miembros
                        
                    </p>
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('iglesias.index')); ?>" class="nav-link <?php echo $__env->yieldContent('iglesias'); ?>">
                    
                    <i class="nav-icon fas fa-lg fa-home"></i>
                    <p>
                        Iglesias & Comunidades
                        
                    </p>
                </a>
            </li>
            
            
            
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>