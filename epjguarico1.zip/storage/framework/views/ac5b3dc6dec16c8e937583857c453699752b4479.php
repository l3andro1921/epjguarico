<div class="container">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="m-0 text-dark"><?php echo $__env->yieldContent("container-title", '@section(\'container-title\')'); ?></h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <?php echo $__env->yieldContent("breadcrumb", '@section(\'breadcrumb\')'); ?>
                
            </ol>
        </div><!-- /.col -->
    </div><!-- /.row -->
</div><!-- /.container-fluid -->
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/miembro/content-header.blade.php ENDPATH**/ ?>