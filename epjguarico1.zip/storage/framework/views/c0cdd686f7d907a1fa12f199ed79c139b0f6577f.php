<!-- The timeline -->
<div class="timeline timeline-inverse">
<?php if($timelines): ?>
<?php $__currentLoopData = $timelines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($contador = 0); ?>

    <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($participante->datos_id == $datos->id && $participante->asistencia == "SI"): ?>
            <?php ($contador = $contador + 1); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(!$contador): ?>
        <?php continue; ?>
    <?php endif; ?>

    <!-- timeline time label -->
    <div class="time-label">
        <?php ($claves = array_rand($color, 1)); ?>
                        <span class="<?php echo e($color[$claves]); ?>">
                          <?php echo e($carbon->parse($actividad->fecha_inicio)->toFormattedDateString()); ?>

                        </span>
    </div>
    <!-- /.timeline-label -->
    <!-- timeline item -->
        <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($participante->status == "Inscrito" && $participante->asistencia == "SI"): ?>
    <div>
        <i class="far fa-flag bg-primary"></i>

        <div class="timeline-item">
            <span class="time"><i class="far fa-clock"></i> <?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>

            <h3 class="timeline-header"><a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>">
                    Participante</a> <em class="small">en el evento: </em>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-muted">
                    <?php echo e(strtoupper($actividad->nombre_evento)); ?></a></h3>

            <div class="timeline-body">
                <?php echo e($actividad->descripcion); ?>

            </div>
            <div class="timeline-footer">
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-folder"></i> Ver</a>
                
            </div>
        </div>
    </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END timeline item -->
    <!-- timeline item -->
        <?php if($actividad->id_coordinador == $datos->id): ?>
            <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($participante->status == "TEAM" && $participante->asistencia == "SI" && $participante->datos_id == $datos->id): ?>
    <div>
        <i class="fas fa-user bg-success"></i>

        <div class="timeline-item">
            <span class="time"><i class="far fa-clock"></i> <?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>

            <h3 class="timeline-header border-0"><a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>">
                    Coordinador</a> <em class="small">en el evento: </em>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-muted">
                    <?php echo e(strtoupper($actividad->nombre_evento)); ?></a></h3>
            </h3>
        </div>
    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <!-- END timeline item -->
    <!-- timeline item -->
        <?php if($actividad->id_administrador == $datos->id): ?>
            <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($participante->status == "TEAM" && $participante->asistencia == "SI" && $participante->datos_id == $datos->id): ?>
    <div>
        <i class="fas fa-user bg-info"></i>

        <div class="timeline-item">
            <span class="time"><i class="far fa-clock"></i> <?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>

            <h3 class="timeline-header border-0"><a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>">
                    Administrador</a> <em class="small">en el evento: </em>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-muted">
                    <?php echo e(strtoupper($actividad->nombre_evento)); ?></a></h3>
            </h3>
        </div>
    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <!-- END timeline item -->
    <!-- timeline item -->
        <?php if($actividad->id_asesor == $datos->id): ?>
            <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($participante->status == "TEAM" && $participante->asistencia == "SI" && $participante->datos_id == $datos->id): ?>
    <div>
        <i class="fas fa-user bg-maroon"></i>

        <div class="timeline-item">
            <span class="time"><i class="far fa-clock"></i> <?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>

            <h3 class="timeline-header border-0"><a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>">
                    Asesor</a> <em class="small">en el evento: </em>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-muted">
                    <?php echo e(strtoupper($actividad->nombre_evento)); ?></a></h3>
            </h3>
        </div>
    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <!-- END timeline item -->
    <!-- timeline item -->
        <?php ($opcion = true); ?>
        <?php $__currentLoopData = $actividad->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($participante->status == "AGENDA" && $participante->datos_id == $datos->id && $participante->asistencia == "SI"): ?>
                <?php if($opcion): ?>
                    <?php ($opcion = false); ?>
    <div>
        <i class="fas fa-comments bg-warning"></i>

        <div class="timeline-item">
            <span class="time"><i class="far fa-clock"></i> <?php echo e($carbon->parse($actividad->updated_at)->diffForHumans()); ?></span>

            <h3 class="timeline-header"><a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>">
                    Exponente</a> <em class="small">en el evento: </em>
                <a href="<?php echo e(route('mieventos.show', $actividad->id)); ?>" class="text-muted">
                    <?php echo e(strtoupper($actividad->nombre_evento)); ?></a></h3>

            <div class="timeline-body">
                <?php ($contador = 0); ?>
                <?php $__currentLoopData = $participante->agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($contador = $contador + 1); ?>
                    <em>Mensaje <?php echo e($contador); ?>: <span class="text-info"><?php echo e($agenda->mensaje); ?></span></em><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
        </div>
    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- END timeline item -->
    <!-- timeline time label -->
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
    <!-- /.timeline-label -->
    <!-- timeline item -->
    
    <div>
        <i class="far fa-clock bg-gray"></i>
    </div>
</div>

<?php /**PATH C:\laragon\www\epjguarico1\resources\views/miembro/home/timeline.blade.php ENDPATH**/ ?>