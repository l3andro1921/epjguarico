

<?php $__env->startSection('container-title'); ?>
    Bienvenido
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    
    <li class="breadcrumb-item active">Home</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('botoncambiar'); ?>
    <?php if($imagen): ?>
        <a href="<?php echo e(route("imagen.edit", $imagen->id)); ?>" class="btn btn-primary btn-block"><b>Cambiar Imagen</b></a>
    <?php else: ?>
        <a href="<?php echo e(route("imagen.create")); ?>" class="btn btn-primary btn-block"><b>Cambiar Imagen</b></a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">

        <div class="card-header p-2">
            <ul class="nav nav-pills">
                <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Actividades</a></li>
                <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Timeline</a></li>
                <li class="nav-item"><a class="nav-link" href="#datos" data-toggle="tab">Datos Personales</a></li>
                <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Settings</a></li>
                <li class="nav-item"><a class="nav-link" href="#seguridad" data-toggle="tab">Seguridad</a></li>
            </ul>
        </div><!-- /.card-header -->

        <div class="card-body">

            <div class="tab-content">

                <div class="active tab-pane" id="activity">
                    <?php echo $__env->make('miembro.home.actividades', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="tab-pane" id="timeline">
                    <?php echo $__env->make('miembro.home.timeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="tab-pane" id="datos">
                    <?php if($datos): ?>
                        <?php echo $__env->make('miembro.home.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php else: ?>
                        <?php echo $__env->make('miembro.home.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>

                <div class="tab-pane" id="settings">
                    <?php echo $__env->make('miembro.home.settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="tab-pane" id="seguridad">
                    <?php echo $__env->make('miembro.home.seguridad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('[data-mask]').inputmask()
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.miembro.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/miembro/home.blade.php ENDPATH**/ ?>