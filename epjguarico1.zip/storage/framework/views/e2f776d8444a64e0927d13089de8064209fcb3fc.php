<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('home')); ?>" class="nav-link">Inicio</a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('contactos.index')); ?>" class="nav-link">Contactos</a>
        </li>
    </ul>

    <?php echo $__env->yieldContent('buscar', ''); ?>
    <!-- SEARCH FORM -->
    
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Messages Dropdown Menu -->
        
        <!-- Notifications Dropdown Menu -->
        
        <li class="nav-item">
            <a href="https://meet.jit.si/epj_guarico" class="nav-link" target="_blank">Video Conferencia</a>
        </li>
        <li class="nav-item dropdown user-menu">
            <?php if($imagen): ?>
                <?php ($foto = 'img/users_img/'.$imagen->nombre_imagen); ?>
            <?php else: ?>
                <?php ($foto = 'img/user.jpg'); ?>
            <?php endif; ?>
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                <img src="<?php echo e(asset($foto)); ?>" class="user-image img-circle elevation-2" alt="User Image">
                <span class="d-none d-md-inline"><?php echo e(ucwords(Auth::user()->name)); ?></span>
            </a>
            <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <!-- User image -->
                <li class="user-header bg-primary">
                    <img src="<?php echo e(asset($foto)); ?>" class="img-circle elevation-2" alt="User Image">
                    <p>
                        <?php echo e(Auth::user()->email); ?>

                        <small><?php echo e(Auth::user()->type); ?></small>
                    </p>
                </li>
                <!-- Menu Body -->
                
                <!-- Menu Footer-->
                <li class="user-footer text-center">
                    
                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-default btn-flat"
                       onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?></a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#">
                <i class="fas fa-th-large"></i>
            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/navbar.blade.php ENDPATH**/ ?>