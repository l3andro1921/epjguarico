
<?php $__env->startSection('title', 'Inicio'); ?>
<?php $__env->startSection('container-title', 'Inicio'); ?>
<?php $__env->startSection('breadcrumb', ''); ?>

<?php $__env->startSection('buscar'); ?>
    <form class="form-inline ml-3" action="/contactos">
        <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="text" name="buscar" placeholder="Buscar Nombre" aria-label="Buscar" required>
            <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box">
                    <span class="info-box-icon bg-info elevation-1"><i class="far fa-bookmark"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Noticias</span>
                        <span class="info-box-number">
                            <?php echo e($cnoticias); ?>

                  
                </span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-danger elevation-1"><i class="far fa-calendar-alt"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Eventos</span>
                        <span class="info-box-number"><?php echo e($ceventos); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <!-- /.col -->

            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-success elevation-1"><i class="fas fa-users"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Usuarios</span>
                        <span class="info-box-number"><?php echo e($cusuarios); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <!-- /.col -->
            <div class="col-12 col-sm-6 col-md-3">
                <div class="info-box mb-3">
                    <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-chart-pie"></i></span>

                    <div class="info-box-content">
                        <span class="info-box-text">Miembros</span>
                        <span class="info-box-number"><?php echo e($cmiembros); ?></span>
                    </div>
                    <!-- /.info-box-content -->
                </div>
                <!-- /.info-box -->
            </div>
            <!-- /.col -->
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        Bienvenid@
                        <div class="card-tools">
                            
                            
                            
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-8">
                                <br>
                                <p>Nombre: <strong><?php echo e(ucwords(auth()->user()->name)); ?></strong></p>
                                <p>Correo: <strong><?php echo e(auth()->user()->email); ?></strong></p>
                            </div>
                            <div class="col-lg-4">

                            <img class="img-thumbnail" src="<?php echo e(asset('img/users_img/'.$imagen->nombre_imagen)); ?>" alt="Entrar">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <!-- USERS LIST -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Ultimos Usuarios</h3>

                        <div class="card-tools">
                            
                            
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body p-0">
                        <ul class="users-list clearfix">
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($usuario->imagen): ?>
                                    <?php ($foto = asset('img/users_img/'.$usuario->imagen->nombre_imagen)); ?>
                                    <?php else: ?>
                                    <?php ($foto = asset('img/user.jpg')); ?>
                                <?php endif; ?>
                            <li>
                                <img src="<?php echo e($foto); ?>" class="img-thumbnail" alt="User Image">
                                <a class="users-list-name" href="/contactos?buscar=<?php echo e($usuario->name); ?>"><?php echo e(ucwords($usuario->name)); ?></a>
                                <span class="users-list-date"><?php echo e($carbon->parse($usuario->created_at)->diffForHumans()); ?></span>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <!-- /.users-list -->
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer text-center">
                        <a href="<?php echo e(route('usuarios.index')); ?>">Ver todos los Usuarios</a>
                    </div>
                    <!-- /.card-footer -->
                </div>
                <!--/.card -->
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/admin/home.blade.php ENDPATH**/ ?>