<?php echo $__env->yieldContent('content', '@section(\'content\')'); ?>
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/guest/content.blade.php ENDPATH**/ ?>