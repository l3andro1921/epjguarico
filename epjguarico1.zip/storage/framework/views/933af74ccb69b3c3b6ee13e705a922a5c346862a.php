<div class="container-fluid">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo $__env->yieldContent("container-title", '@section(\'container-title\')'); ?></h1>
        </div>
        <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <?php echo $__env->yieldContent("breadcrumb", '@section(\'breadcrumb\')'); ?>
                
            </ol>
        </div>
    </div>
</div><!-- /.container-fluid -->
<?php /**PATH C:\laragon\www\epjguarico1\resources\views/layouts/admin/content-header.blade.php ENDPATH**/ ?>