

<?php $__env->startSection('container-title'); ?>
    <span>Galeria</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                
                <div class="card-body">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-sm-3">
                            <a href="<?php echo e(Storage::disk('public')->url($gallery->imagen)); ?>" data-toggle="lightbox" data-title="Imagen" data-gallery="gallery">
                                <img src="<?php echo e(Storage::disk('public')->url($gallery->imagen)); ?>" class="img-thumbnail mb-2" alt="imagen">
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-center text-danger">No Hay Imagenes Disponibles</span>
                        <?php endif; ?>
                    </div>
                </div>
                        <?php if(count($galleries)): ?>
                            <div class="mt-2 mx-auto">
                                <?php echo e($galleries->links()); ?>

                            </div>
                        <?php endif; ?>
            </div>

        </div>
        <!-- /.col-md-6 -->
    </div>
    <!-- /.row -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.guest.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/guest/galeria.blade.php ENDPATH**/ ?>