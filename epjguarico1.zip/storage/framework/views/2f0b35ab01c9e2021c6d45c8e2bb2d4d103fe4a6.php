

<?php $__env->startSection('container-title'); ?>
    Bienvenido
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
    <li class="breadcrumb-item active">Cambiar Imagen</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Cambiar Imagen</h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <?php echo Form::open(['route' => 'imagen.store', 'method' => 'POST', 'files' => true, 'id' => 'form1']); ?>

        <div class="card-body">

            <div class="form-group">
                <label>Imagen de Perfil</label>
                <div class="input-group">
                    <div class="custom-file">
                        <input type="file" name="image" class="custom-file-input" id="imgInp" accept="image/png, image/jpeg" required>
                        <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                    </div>
                </div>
            </div>

            <div class="form-group text-center">
                <img id="blah" src="" class="img-fluid" width="50%" height="50%" />
            </div>

        </div>
        <!-- /.card-body -->

        <div class="card-footer text-right">
            <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary">Cancelar</a>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </div>

        <?php echo Form::close(); ?>

    </div>
    <!-- /.card -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function readImage (input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result); // Renderizamos la imagen
                    $('#blah').attr('class', 'img-thumbnail');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imgInp").change(function () {
            // Código a ejecutar cuando se detecta un cambio de archivO
            readImage(this);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.miembro.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\epjguarico1\resources\views/miembro/imagen/create.blade.php ENDPATH**/ ?>